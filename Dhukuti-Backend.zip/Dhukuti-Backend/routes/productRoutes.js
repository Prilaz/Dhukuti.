import express from "express";
import Product from "../models/Product.js";
import { upload } from "../middleware/upload.js"; // Can be Cloudinary or Multer local
import protect from "../middleware/authMiddleware.js"; // ✅ Your JWT middleware
import isAdmin from "../middleware/isAdmin.js"; // ✅ Check if user is admin

const router = express.Router();

// POST: Add Product (Only Admin)
router.post("/", protect, isAdmin, upload.single("image"), async (req, res) => {
  try {
    const { title, price, category } = req.body;
    const image = req.file?.path || `/uploads/${req.file.filename}`;

    const product = new Product({ title, price, category, image });
    await product.save();

    res.status(201).json({ product });
  } catch (error) {
    res.status(500).json({ message: "Failed to add product", error });
  }
});

// GET: All Products
router.get("/", async (req, res) => {
  try {
    const products = await Product.find();
    res.json(products);
  } catch (error) {
    res.status(500).json({ message: "Failed to get products", error });
  }
});

// DELETE: Product (Only Admin)
router.delete("/:id", protect, isAdmin, async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ message: "Product deleted" });
  } catch (error) {
    res.status(500).json({ message: "Failed to delete product", error });
  }
});

export default router;
